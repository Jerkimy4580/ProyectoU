# 🌱 EcoPoint

EcoPoint es un sistema web de recompensas por reciclaje que permite registrar materiales reciclados, asignar puntos a los usuarios y canjear dichos puntos por premios.  
El sistema está diseñado con una arquitectura **frontend + backend separados**, y maneja **roles de usuario** para controlar las funcionalidades.

---

## 🚀 Tecnologías Utilizadas

### Frontend

- React (Vite)
- JavaScript
- CSS por componente
- Fetch API

### Backend

- Node.js
- Express
- MongoDB
- Mongoose
- bcryptjs (encriptación de contraseñas)

---

## 🧠 Arquitectura del Proyecto

EcoPoint
│
├── backend # API REST + lógica de negocio
│
└── frontend # Aplicación React (interfaz de usuario)

- El **backend** corre en `http://localhost:5000`
- El **frontend** corre en `http://localhost:5173`
- Se comunican mediante peticiones HTTP (`fetch`)

---

## 👥 Roles del Sistema

### 🟢 Usuario

- Registrarse con cédula y contraseña
- Iniciar sesión
- Ver puntos acumulados
- Ver historial de reciclaje
- Ver premios disponibles
- Canjear premios
- Cerrar sesión

### 🔵 Recolector

- Iniciar sesión
- Ver materiales reciclables
- Registrar reciclaje de usuarios (cédula, material, peso)
- Asignar puntos automáticamente
- Cerrar sesión

### 🟣 Administrador

- Iniciar sesión
- Crear y eliminar materiales reciclables
- Definir puntos por kilogramo
- Crear y eliminar premios
- Asignar roles a usuarios (usuario, recolector, admin)
- Cerrar sesión

---

## 🔐 Autenticación y Sesión

- Registro con contraseña encriptada (bcrypt)
- Login con validación de credenciales
- Persistencia de sesión usando `localStorage`
- Logout que limpia la sesión correctamente

---

## 📂 Estructura del Frontend

frontend/src
│
├── components
│ ├── Login.jsx
│ ├── Login.css
│ ├── Register.jsx
│ └── Register.css
│
├── views
│ ├── UsuarioView.jsx
│ ├── UsuarioView.css
│ ├── RecolectorView.jsx
│ ├── RecolectorView.css
│ ├── AdminView.jsx
│ └── AdminView.css
│
├── App.jsx
├── main.jsx
└── index.css

---

## 📂 Estructura del Backend

backend
│
├── models
│ ├── User.js
│ ├── Material.js
│ └── Premio.js
│
├── routes
│ ├── user.routes.js
│ ├── material.routes.js
│ ├── reciclaje.routes.js
│ └── premio.routes.js
│
├── index.js
├── .env
└── package.json

---

## ⚙️ Instalación y Ejecución

### 1️⃣ Clonar el repositorio

```bash
git clone <url-del-repositorio>
cd EcoPoint

cd backend
npm install
npm run dev

MONGO_URI=mongodb://localhost:27017/ecopoint
PORT=5000

cd frontend
npm install
npm run dev

http://localhost:5173
```
